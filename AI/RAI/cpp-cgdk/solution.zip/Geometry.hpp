#pragma once

#ifndef GEOMETRY_HPP
#define GEOMETRY_HPP

#include <cmath>

#include "MyStrategy.h"

using namespace model;

struct Vector2f
{
  Vector2f(double x = 0.0, double y = 0.0) : x(x), y(y)
  {
  }
  Vector2f(const Unit& unit)
  {
    x = unit.x();
    y = unit.y();
  }
  double x, y;
};

double getDistance(const Vector2f& a, const Vector2f& b)
{
  return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}

#endif // GEOMETRY_HPP
